
public class Caine extends Animal {
	public Caine(boolean h){
		super(h);
	}
	@Override 
	public void feed(String str){
		System.out.println("override");
	}
	
	
	
}
