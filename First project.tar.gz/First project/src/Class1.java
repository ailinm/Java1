import Package1.*;

public class Class1 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Client c1=new Client();
		Client c2=new Client();
		char prim;
//		Character obj=new Character('dhas');
	//	prim=new char('dd');
		PostOffEmp p =null;
		//System.out.println(p.processReq("java"));
		
		Boolean z;
	   // try{
	    //	int y=Integer.parseInt("ana");
	    //	System.out.println(y);
	    //}catch(NumberFormatException ex){
	    //	System.out.println("success");
	    //}
		Caine d =new Caine(true);
		Animal a=new Animal(true);
		a.getType(d);
		
	    //System.out.println(c1.name);
		//System.out.println(c2.name);
		//c1.name="tanta";
		//String s1=new String("ana");
		//String s2=new String("ana");
		//Mountains m=Mountains.MERIDIONALI;
		//System.out.println(m.ordinal());
		//System.out.println(Mountains.valueOf("MERIDIONALI"));
	//	System.out.println(Mountains);
		//System.out.println(m);
		//if ( s1.equals(s2))
		//	System.out.println("True");
		//else 
		//	System.out.println("False");
		//PostOffEmp posta=new PostOffEmp();
	    //System.out.println(c1.getName);
		//System.out.println("Hello");
		//System.out.println("abc" + " "+ 3 );
		//System.out.println(c1.name);
		//System.out.println(c2.name);
		//System.out.println(posta.processReq("posta"));
		

	}

}
