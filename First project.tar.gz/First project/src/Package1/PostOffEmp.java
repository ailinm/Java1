
package Package1;
public class PostOffEmp {
	String pack;
	public boolean processReq(String str){
		
		if (str == "posta")
			return false;
		return true;
	}

}
